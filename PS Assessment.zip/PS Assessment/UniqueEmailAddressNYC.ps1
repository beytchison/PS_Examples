$MailboxUsers = Import-Csv C:\Temp\Users.csv
Write-Output $MailboxUsers | Where {$_.Site -EQ "NYC"} | Select emailaddress,userprincipalname -Unique
