$MailboxUsers = Import-Csv C:\Temp\Users.csv
Write-Output $MailboxUsers | Measure-Object