$MailboxUsers = Import-Csv C:\Temp\Users.csv
$TopTen = $MailboxUsers | Sort MailboxSizeGB -Descending | select emailaddress -first 10
$TopTenUsernames = $TopTen -replace "@.*"
