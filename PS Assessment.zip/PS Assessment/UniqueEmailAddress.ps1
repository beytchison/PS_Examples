$MailboxUsers = Import-Csv C:\Temp\Users.csv
Write-Output $MailboxUsers | Select emailaddress,userprincipalname -Unique
