$MailboxUsers = Import-Csv C:\Temp\Users.csv
Write-Output $MailboxUsers | Where {$_.MailboxSizeGB -GT "10" -and $_.AccountType -EQ "Employee"}
